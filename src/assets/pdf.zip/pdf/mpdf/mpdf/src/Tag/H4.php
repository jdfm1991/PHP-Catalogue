<?php

namespace Mpdf\Tag;

class H4 extends BlockTag
{


}
